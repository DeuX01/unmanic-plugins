**<span style="color:#56adda">1.0.0</span>**
- Initial version
- Update plugin ID to avoid conflicts
- Send task notifications using Discord embeds
- Ensure proper formatting and inclusion of colors in Discord notifications

**<span style="color:#56adda">1.0.1</span>**
- Corrected some text